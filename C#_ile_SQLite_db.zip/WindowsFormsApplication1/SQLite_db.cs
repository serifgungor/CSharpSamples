﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SQLite;
using System.IO;

namespace WindowsFormsApplication1
{
    class SQLite_db
    {
        public void Create_SQLite_db(string databaseName)
        {
            string dbName = databaseName;
            SQLiteConnection.CreateFile(dbName);
            SQLiteConnection conn = new SQLiteConnection("Data Source=" + dbName + ";Version=3;");
            conn.Open();
            conn.Close();
        }
        public int Check_SQLite_db(string SQLiteFileName)
        {
            if (File.Exists(SQLiteFileName))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        public int Create_SQLite_tbl(string dbName, string sqlQuery)
        {
            int mode = 0;
            try
            {
                SQLiteConnection conn = new SQLiteConnection("Data Source=" + dbName + ";Version=3;");
                conn.Open();

                try
                {
                    SQLiteCommand command = new SQLiteCommand(sqlQuery, conn);
                    command.ExecuteNonQuery();
                    mode = 1;
                }
                catch (Exception ex)
                {
                    mode = 0;
                }

                conn.Close();
            }
            catch (Exception ex)
            {
                mode = -1;
            }
            return mode;
        }
        public int Check_SQLite_tbl(string dbName, string tableName)
        {
            int count = 0;
            SQLiteConnection conn = new SQLiteConnection("Data Source=" + dbName + ";Version=3;");
            conn.Open();

            SQLiteCommand command = new SQLiteCommand("SELECT name FROM sqlite_master WHERE type='table'", conn);
            command.ExecuteNonQuery();
            SQLiteDataReader dr = command.ExecuteReader();
            while (dr.Read())
            {
                if (dr["name"].ToString() == tableName)
                {
                    count++;
                }
            }
            conn.Close();
            return count;
        }
        public int IUD_SQLite_tbl(string dbName, string sqlQuery)
        {
            int mode = 0;
            try
            {
                SQLiteConnection conn = new SQLiteConnection("Data Source=" + dbName + ";Version=3;");
                conn.Open();

                try
                {
                    SQLiteCommand command = new SQLiteCommand(sqlQuery, conn);
                    command.ExecuteNonQuery();
                    mode = 1;
                }
                catch (Exception ex)
                {
                    mode = 0;
                }

                conn.Close();
            }
            catch (Exception ex)
            {
                mode = -1;
            }
            return mode;

        }

    }
}
