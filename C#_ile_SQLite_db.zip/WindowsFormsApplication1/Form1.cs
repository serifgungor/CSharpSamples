﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string SQLiteFileName = "myDB.sqlite";

        SQLite_db db = new SQLite_db();

        private void Fill_SavedConnections_Table(string SQLiteFileName)
        {
            listView1.Clear();
            listView1.Columns.Clear();
            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.FullRowSelect = true;

            //Add column header
            listView1.Columns.Add("ID", 30);//50 is text's weight
            listView1.Columns.Add("Name", 100);
            listView1.Columns.Add("Yas", 70);

            //Add items in the listview
            string[] arr = new string[9];
            ListViewItem itm;



            try
            {
                string dbName = SQLiteFileName;
                //SQLiteConnection.CreateFile(dbName);

                SQLiteConnection conn = new SQLiteConnection("Data Source=" + dbName + ";Version=3;");
                conn.Open();







                SQLiteCommand cmd = conn.CreateCommand();
                cmd.CommandText = "select * from uyeler";
                cmd.ExecuteNonQuery();
                SQLiteDataReader dr = cmd.ExecuteReader();



                while (dr.Read())
                {
                    //Add items
                    arr[0] = dr["id"].ToString();
                    arr[1] = dr["name"].ToString();
                    arr[2] = dr["yas"].ToString();
                    itm = new ListViewItem(arr);
                    listView1.Items.Add(itm);
                }


                conn.Close();
            }catch(Exception ex)
            {

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            if (db.Check_SQLite_db(SQLiteFileName) == 0){
                db.Create_SQLite_db(SQLiteFileName);
            }

            Fill_SavedConnections_Table(SQLiteFileName);

            if (db.Check_SQLite_tbl(SQLiteFileName, "uyeler") == 0) { 
                int createMode = db.Create_SQLite_tbl(SQLiteFileName, "create table uyeler (id INTEGER PRIMARY KEY, name varchar(20), yas int)");
                if (createMode == 1)
                {
                    MessageBox.Show("Tablo oluşturuldu.");
                }
                else if (createMode == 0)
                {
                    MessageBox.Show("Tablo oluşturulamadı.");
                }
                else if (createMode == -1)
                {
                    MessageBox.Show("Veritabanına bağlanılamadı.");
                }
            }

            


        }

        private void button1_Click(object sender, EventArgs e)
        {
            int crtMode = db.IUD_SQLite_tbl(SQLiteFileName, "insert into uyeler(id, name, yas) values(NULL, '"+textBox1.Text+"', "+textBox2.Text+")");
            if (crtMode == 1)
            {
                MessageBox.Show("Veri başarıyla eklendi.");
            }
            else if (crtMode == 0)
            {
                MessageBox.Show("Veri eklenirken bir sorun oluştu.");
            }
            else if (crtMode == -1)
            {
                MessageBox.Show("Veritabanına bağlanılamadı.");
            }

            Fill_SavedConnections_Table(SQLiteFileName);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int deviceId;
                deviceId = int.Parse(listView1.SelectedItems[0].SubItems[0].Text);

                int crtMode = db.IUD_SQLite_tbl(SQLiteFileName, "delete from uyeler where id="+deviceId+"");
                if (crtMode == 1)
                {
                    MessageBox.Show("Veri başarıyla silindi.");
                }
                else if (crtMode == 0)
                {
                    MessageBox.Show("Veri silinirken bir sorun oluştu.");
                }
                else if (crtMode == -1)
                {
                    MessageBox.Show("Veritabanına bağlanılamadı.");
                }

                Fill_SavedConnections_Table(SQLiteFileName);

            }
            catch (Exception)
            {
                MessageBox.Show("Lütfen veri seçiniz.", "Hata !");

            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int deviceId;
                deviceId = int.Parse(listView1.SelectedItems[0].SubItems[0].Text);
                //MessageBox.Show(deviceId.ToString());
                textBox3.Text = listView1.SelectedItems[0].SubItems[1].Text;
                textBox4.Text = listView1.SelectedItems[0].SubItems[2].Text;
                textBox5.Text = listView1.SelectedItems[0].SubItems[0].Text;
            }
            catch (Exception ex){}
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                int crtMode = db.IUD_SQLite_tbl(SQLiteFileName, "UPDATE uyeler SET name = '"+textBox3.Text+ "', yas = '" + int.Parse(textBox4.Text) + "' WHERE id = " + int.Parse(textBox5.Text) + "");
                if (crtMode == 1)
                {
                    MessageBox.Show("Veri başarıyla güncellendi.");
                }
                else if (crtMode == 0)
                {
                    MessageBox.Show("Veri güncellenirken bir sorun oluştu.");
                }
                else if (crtMode == -1)
                {
                    MessageBox.Show("Veritabanına bağlanılamadı.");
                }

                Fill_SavedConnections_Table(SQLiteFileName);

            }
            catch (Exception)
            {
               
            }
        }
    }
}
